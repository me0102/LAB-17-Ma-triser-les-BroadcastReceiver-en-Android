package com.example.receiverdemo;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private AirplaneModeReceiver airplaneReceiver;
    private boolean isReceiverRegistered = false;

    // btnSendCustom a été supprimé d'ici pour résoudre l'avertissement Lint
    private Button btnToggleAirplane;
    private TextView tvStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        airplaneReceiver = new AirplaneModeReceiver();
        tvStatus = findViewById(R.id.tvStatus);
        btnToggleAirplane = findViewById(R.id.btnToggleAirplane);

        // btnSendCustom devient une variable locale propre à onCreate()
        Button btnSendCustom = findViewById(R.id.btnSendCustom);

        btnToggleAirplane.setOnClickListener(v -> toggleAirplaneReceiver());
        btnSendCustom.setOnClickListener(v -> sendCustomBroadcast());
    }

    private void toggleAirplaneReceiver() {
        if (!isReceiverRegistered) {
            IntentFilter filter = new IntentFilter(Intent.ACTION_AIRPLANE_MODE_CHANGED);
            ContextCompat.registerReceiver(this, airplaneReceiver, filter, ContextCompat.RECEIVER_EXPORTED);

            isReceiverRegistered = true;
            // Utilisation sécurisée des ressources String
            tvStatus.setText(R.string.status_enabled);
            btnToggleAirplane.setText(R.string.btn_disable);
        } else {
            unregisterReceiver(airplaneReceiver);
            isReceiverRegistered = false;
            // Utilisation sécurisée des ressources String
            tvStatus.setText(R.string.status_disabled);
            btnToggleAirplane.setText(R.string.btn_enable);
        }
    }

    private void sendCustomBroadcast() {
        Intent intent = new Intent("com.example.receiverdemo.CUSTOM_EVENT");
        intent.setClass(this, CustomEventReceiver.class);
        intent.putExtra("message", "Bonjour depuis le custom broadcast !");
        sendBroadcast(intent);
    }

    @Override
    protected void onDestroy() {
        if (isReceiverRegistered) {
            unregisterReceiver(airplaneReceiver);
        }
        super.onDestroy();
    }
}