package com.example.receiverdemo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

public class AirplaneModeReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_AIRPLANE_MODE_CHANGED.equals(intent.getAction())) {
            // Android passes a boolean extra "state" to tell us if it's ON or OFF
            boolean isAirplaneModeOn = intent.getBooleanExtra("state", false);
            String state = isAirplaneModeOn ? "ACTIVÉ" : "DÉSACTIVÉ";
            Toast.makeText(context, "Mode Avion : " + state, Toast.LENGTH_LONG).show();
            Log.d("ReceiverDemoLog", "ALERTE: Le Mode Avion a changé. Nouvel état = " + state);
        }
    }
}